"""Local companion distribution: public server and network adapters are not bundled."""
